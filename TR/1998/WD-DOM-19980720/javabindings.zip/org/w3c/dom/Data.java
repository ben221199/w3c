package org.w3c.dom;

public interface Data extends Node {
   public String             getData();
   public void               setData(String arg);

   public int                getSize();

   public String             substring(int start, 
                                       int count)
                                       throws DOMException;
   public void               append(String arg);
   public void               insert(int offset, 
                                    String arg)
                                    throws DOMException;
   public void               delete(int offset, 
                                    int count)
                                    throws DOMException;
   public void               replace(int offset, 
                                     int count, 
                                     String arg)
                                     throws DOMException;
}

