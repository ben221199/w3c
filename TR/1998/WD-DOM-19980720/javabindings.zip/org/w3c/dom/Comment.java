package org.w3c.dom;

public interface Comment extends Data {
}

