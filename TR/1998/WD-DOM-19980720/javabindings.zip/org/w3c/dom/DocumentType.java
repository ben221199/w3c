package org.w3c.dom;

public interface DocumentType extends Node {
   public String             getName();
   public void               setName(String arg);

   public NamedNodeMap       getEntities();

   public NamedNodeMap       getNotations();

}

