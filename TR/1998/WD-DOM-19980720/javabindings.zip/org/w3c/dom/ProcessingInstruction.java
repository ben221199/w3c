package org.w3c.dom;

public interface ProcessingInstruction extends Node {
   public String             getTarget();
   public void               setTarget(String arg);

   public String             getData();
   public void               setData(String arg);

}

