package org.w3c.dom;

public interface Text extends Data {
   public Text               splitText(int offset);
   public Text               joinText(Text node1, 
                                      Text node2);
}

