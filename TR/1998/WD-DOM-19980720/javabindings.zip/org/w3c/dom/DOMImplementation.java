package org.w3c.dom;

public interface DOMImplementation {
   public boolean            hasFeature(String feature, 
                                        String version);
}

