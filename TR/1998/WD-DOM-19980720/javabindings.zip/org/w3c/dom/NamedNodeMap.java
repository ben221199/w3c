package org.w3c.dom;

public interface NamedNodeMap {
   public Node               getNamedItem(String name);
   public void               setNamedItem(Node arg);
   public Node               removeNamedItem(String name);
   public Node               item(int index);
   public int                getSize();

}

