package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLInputElement extends HTMLElement {
   public String             getDefaultValue();
   public void               setDefaultValue(String arg);

   public boolean            getDefaultChecked();
   public void               setDefaultChecked(boolean arg);

   public HTMLFormElement    getForm();

   public String             getAccept();
   public void               setAccept(String arg);

   public String             getAccessKey();
   public void               setAccessKey(String arg);

   public String             getAlign();
   public void               setAlign(String arg);

   public String             getAlt();
   public void               setAlt(String arg);

   public boolean            getChecked();
   public void               setChecked(boolean arg);

   public boolean            getDisabled();
   public void               setDisabled(boolean arg);

   public long               getMaxLength();
   public void               setMaxLength(long arg);

   public String             getName();
   public void               setName(String arg);

   public boolean            getReadOnly();
   public void               setReadOnly(boolean arg);

   public String             getSize();
   public void               setSize(String arg);

   public String             getSrc();
   public void               setSrc(String arg);

   public long               getTabIndex();
   public void               setTabIndex(long arg);

   public String             getType();

   public String             getUseMap();
   public void               setUseMap(String arg);

   public String             getValue();
   public void               setValue(String arg);

   public void               blur();
   public void               focus();
   public void               select();
   public void               click();
}

