package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLAnchorElement extends HTMLElement {
   public String             getAccessKey();
   public void               setAccessKey(String arg);

   public String             getCharset();
   public void               setCharset(String arg);

   public String             getCoords();
   public void               setCoords(String arg);

   public String             getHref();
   public void               setHref(String arg);

   public String             getHreflang();
   public void               setHreflang(String arg);

   public String             getName();
   public void               setName(String arg);

   public String             getRel();
   public void               setRel(String arg);

   public String             getRev();
   public void               setRev(String arg);

   public String             getShape();
   public void               setShape(String arg);

   public long               getTabIndex();
   public void               setTabIndex(long arg);

   public String             getTarget();
   public void               setTarget(String arg);

   public String             getType();
   public void               setType(String arg);

   public void               blur();
   public void               focus();
}

