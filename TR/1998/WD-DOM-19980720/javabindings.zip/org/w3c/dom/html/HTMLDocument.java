package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLDocument extends Document {
   public String             getTitle();
   public void               setTitle(String arg);

   public String             getReferrer();

   public String             getFileSize();

   public String             getFileCreatedDate();

   public String             getFileModifiedDate();

   public String             getFileUpdatedDate();

   public String             getDomain();

   public String             getURL();

   public HTMLElement        getBody();
   public void               setBody(HTMLElement arg);

   public HTMLCollection     getImages();

   public HTMLCollection     getApplets();

   public HTMLCollection     getLinks();

   public HTMLCollection     getForms();

   public HTMLCollection     getAnchors();

   public String             getCookie();
   public void               setCookie(String arg);

   public void               open();
   public void               close();
   public void               write(String text);
   public void               writeln(String text);
   public Element            getElementById(String elementId);
   public NodeList           getElementsByName(String elementName);
}

