package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLParamElement extends HTMLElement {
   public String             getName();
   public void               setName(String arg);

   public String             getType();
   public void               setType(String arg);

   public String             getValue();
   public void               setValue(String arg);

   public String             getValueType();
   public void               setValueType(String arg);

}

