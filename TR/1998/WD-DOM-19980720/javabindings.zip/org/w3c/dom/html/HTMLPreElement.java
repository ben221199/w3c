package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLPreElement extends HTMLElement {
   public long               getWidth();
   public void               setWidth(long arg);

}

