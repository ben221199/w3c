package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLBRElement extends HTMLElement {
   public String             getClear();
   public void               setClear(String arg);

}

