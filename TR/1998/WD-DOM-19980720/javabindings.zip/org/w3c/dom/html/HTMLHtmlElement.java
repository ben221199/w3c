package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLHtmlElement extends HTMLElement {
   public String             getVersion();
   public void               setVersion(String arg);

}

