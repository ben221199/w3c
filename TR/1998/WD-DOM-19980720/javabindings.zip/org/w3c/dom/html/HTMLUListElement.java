package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLUListElement extends HTMLElement {
   public boolean            getCompact();
   public void               setCompact(boolean arg);

   public String             getType();
   public void               setType(String arg);

}

