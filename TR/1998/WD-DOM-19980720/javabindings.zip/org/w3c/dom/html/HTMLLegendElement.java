package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLLegendElement extends HTMLElement {
   public HTMLFormElement    getForm();

   public String             getAccessKey();
   public void               setAccessKey(String arg);

   public String             getAlign();
   public void               setAlign(String arg);

}

