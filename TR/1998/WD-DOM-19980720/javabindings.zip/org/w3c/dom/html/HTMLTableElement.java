package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLTableElement extends HTMLElement {
   public HTMLTableCaptionElement getCaption();
   public void               setCaption(HTMLTableCaptionElement arg);

   public HTMLTableSectionElement getTHead();
   public void               setTHead(HTMLTableSectionElement arg);

   public HTMLTableSectionElement getTFoot();
   public void               setTFoot(HTMLTableSectionElement arg);

   public HTMLCollection     getRows();

   public HTMLCollection     getTBodies();
   public void               setTBodies(HTMLCollection arg);

   public String             getAlign();
   public void               setAlign(String arg);

   public String             getBgColor();
   public void               setBgColor(String arg);

   public String             getBorder();
   public void               setBorder(String arg);

   public String             getCellPadding();
   public void               setCellPadding(String arg);

   public String             getCellSpacing();
   public void               setCellSpacing(String arg);

   public String             getFrame();
   public void               setFrame(String arg);

   public String             getRules();
   public void               setRules(String arg);

   public String             getSummary();
   public void               setSummary(String arg);

   public String             getWidth();
   public void               setWidth(String arg);

   public HTMLElement        createTHead();
   public void               deleteTHead();
   public HTMLElement        createTFoot();
   public void               deleteTFoot();
   public HTMLElement        createCaption();
   public void               deleteCaption();
   public HTMLElement        insertRow(long index);
   public void               deleteRow(long index);
}

