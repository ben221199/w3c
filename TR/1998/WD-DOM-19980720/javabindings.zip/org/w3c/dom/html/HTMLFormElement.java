package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLFormElement extends HTMLElement {
   public HTMLCollection     getElements();

   public long               getLength();

   public String             getName();
   public void               setName(String arg);

   public String             getAcceptCharset();
   public void               setAcceptCharset(String arg);

   public String             getAction();
   public void               setAction(String arg);

   public String             getEnctype();
   public void               setEnctype(String arg);

   public String             getMethod();
   public void               setMethod(String arg);

   public String             getTarget();
   public void               setTarget(String arg);

}

