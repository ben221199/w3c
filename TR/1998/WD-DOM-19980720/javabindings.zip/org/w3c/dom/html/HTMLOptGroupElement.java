package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLOptGroupElement extends HTMLElement {
   public boolean            getDisabled();
   public void               setDisabled(boolean arg);

   public String             getLabel();
   public void               setLabel(String arg);

}

