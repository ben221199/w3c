package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLTextAreaElement extends HTMLElement {
   public String             getDefaultValue();
   public void               setDefaultValue(String arg);

   public HTMLFormElement    getForm();

   public String             getAccessKey();
   public void               setAccessKey(String arg);

   public long               getCols();
   public void               setCols(long arg);

   public boolean            getDisabled();
   public void               setDisabled(boolean arg);

   public String             getName();
   public void               setName(String arg);

   public boolean            getReadOnly();
   public void               setReadOnly(boolean arg);

   public long               getRows();
   public void               setRows(long arg);

   public long               getTabIndex();
   public void               setTabIndex(long arg);

   public String             getType();

   public void               blur();
   public void               focus();
   public void               select();
}

