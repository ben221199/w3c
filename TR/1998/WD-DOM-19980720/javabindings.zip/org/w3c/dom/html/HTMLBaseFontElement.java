package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLBaseFontElement extends HTMLElement {
   public String             getColor();
   public void               setColor(String arg);

   public String             getFace();
   public void               setFace(String arg);

   public String             getSize();
   public void               setSize(String arg);

}

