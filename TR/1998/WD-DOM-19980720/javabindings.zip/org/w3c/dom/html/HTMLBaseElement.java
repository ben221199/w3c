package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLBaseElement extends HTMLElement {
   public String             getHref();
   public void               setHref(String arg);

   public String             getTarget();
   public void               setTarget(String arg);

}

