package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLLinkElement extends HTMLElement {
   public boolean            getDisabled();
   public void               setDisabled(boolean arg);

   public String             getCharset();
   public void               setCharset(String arg);

   public String             getHref();
   public void               setHref(String arg);

   public String             getHreflang();
   public void               setHreflang(String arg);

   public String             getMedia();
   public void               setMedia(String arg);

   public String             getRel();
   public void               setRel(String arg);

   public String             getRev();
   public void               setRev(String arg);

   public String             getTarget();
   public void               setTarget(String arg);

   public String             getType();
   public void               setType(String arg);

}

