package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLOListElement extends HTMLElement {
   public boolean            getCompact();
   public void               setCompact(boolean arg);

   public long               getStart();
   public void               setStart(long arg);

   public String             getType();
   public void               setType(String arg);

}

