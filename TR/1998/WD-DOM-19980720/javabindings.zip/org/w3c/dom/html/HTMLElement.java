package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLElement extends Element {
   public String             getId();
   public void               setId(String arg);

   public String             getTitle();
   public void               setTitle(String arg);

   public String             getLang();
   public void               setLang(String arg);

   public String             getDir();
   public void               setDir(String arg);

   public String             getClassName();
   public void               setClassName(String arg);

}

