package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLTbodyElement extends HTMLElement {
   public String             getAlign();
   public void               setAlign(String arg);

   public String             getCh();
   public void               setCh(String arg);

   public String             getChOff();
   public void               setChOff(String arg);

   public String             getVAlign();
   public void               setVAlign(String arg);

}

