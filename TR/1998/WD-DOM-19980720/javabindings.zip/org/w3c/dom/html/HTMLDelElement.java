package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLDelElement extends HTMLElement {
   public String             getCite();
   public void               setCite(String arg);

   public String             getDateTime();
   public void               setDateTime(String arg);

}

