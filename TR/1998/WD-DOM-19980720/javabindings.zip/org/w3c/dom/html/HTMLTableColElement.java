package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLTableColElement extends HTMLElement {
   public String             getAlign();
   public void               setAlign(String arg);

   public String             getCh();
   public void               setCh(String arg);

   public String             getChOff();
   public void               setChOff(String arg);

   public long               getSpan();
   public void               setSpan(long arg);

   public String             getVAlign();
   public void               setVAlign(String arg);

   public String             getWidth();
   public void               setWidth(String arg);

}

