package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLFieldSetElement extends HTMLElement {
   public HTMLFormElement    getForm();

}

