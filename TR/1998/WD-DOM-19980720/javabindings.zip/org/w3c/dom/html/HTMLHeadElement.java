package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLHeadElement extends HTMLElement {
   public String             getProfile();
   public void               setProfile(String arg);

}

