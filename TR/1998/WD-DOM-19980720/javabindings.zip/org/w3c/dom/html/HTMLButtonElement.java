package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLButtonElement extends HTMLElement {
   public HTMLFormElement    getForm();

   public String             getAccessKey();
   public void               setAccessKey(String arg);

   public boolean            getDisabled();
   public void               setDisabled(boolean arg);

   public String             getName();
   public void               setName(String arg);

   public long               getTabIndex();
   public void               setTabIndex(long arg);

   public String             getType();

   public String             getValue();
   public void               setValue(String arg);

}

