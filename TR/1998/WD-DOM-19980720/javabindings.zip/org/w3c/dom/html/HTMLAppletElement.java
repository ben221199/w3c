package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLAppletElement extends HTMLElement {
   public String             getAlign();
   public void               setAlign(String arg);

   public String             getAlt();
   public void               setAlt(String arg);

   public String             getArchive();
   public void               setArchive(String arg);

   public String             getCode();
   public void               setCode(String arg);

   public String             getCodeBase();
   public void               setCodeBase(String arg);

   public String             getHeight();
   public void               setHeight(String arg);

   public String             getHspace();
   public void               setHspace(String arg);

   public String             getName();
   public void               setName(String arg);

   public String             getObject();
   public void               setObject(String arg);

   public String             getVspace();
   public void               setVspace(String arg);

   public String             getWidth();
   public void               setWidth(String arg);

}

