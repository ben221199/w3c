package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLOptionElement extends HTMLElement {
   public HTMLFormElement    getForm();

   public boolean            getDefaultSelected();
   public void               setDefaultSelected(boolean arg);

   public String             getText();

   public long               getIndex();
   public void               setIndex(long arg);

   public boolean            getDisabled();
   public void               setDisabled(boolean arg);

   public String             getLabel();
   public void               setLabel(String arg);

   public boolean            getSelected();

   public String             getValue();
   public void               setValue(String arg);

}

