package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLMenuElement extends HTMLElement {
   public boolean            getCompact();
   public void               setCompact(boolean arg);

}

