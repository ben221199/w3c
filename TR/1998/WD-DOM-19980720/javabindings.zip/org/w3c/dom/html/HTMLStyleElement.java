package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLStyleElement extends HTMLElement {
   public boolean            getDisabled();
   public void               setDisabled(boolean arg);

   public String             getMedia();
   public void               setMedia(String arg);

   public String             getType();
   public void               setType(String arg);

}

