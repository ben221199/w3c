package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLFrameElement extends HTMLElement {
   public String             getFrameBorder();
   public void               setFrameBorder(String arg);

   public String             getLongDesc();
   public void               setLongDesc(String arg);

   public String             getMarginHeight();
   public void               setMarginHeight(String arg);

   public String             getMarginWidth();
   public void               setMarginWidth(String arg);

   public String             getName();
   public void               setName(String arg);

   public boolean            getNoResize();
   public void               setNoResize(boolean arg);

   public String             getScrolling();
   public void               setScrolling(String arg);

   public String             getSrc();
   public void               setSrc(String arg);

}

