package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLLabelElement extends HTMLElement {
   public HTMLFormElement    getForm();

   public String             getAccessKey();
   public void               setAccessKey(String arg);

   public String             getHtmlFor();
   public void               setHtmlFor(String arg);

}

