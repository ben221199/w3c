package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLMapElement extends HTMLElement {
   public HTMLCollection     getAreas();

   public String             getName();
   public void               setName(String arg);

}

