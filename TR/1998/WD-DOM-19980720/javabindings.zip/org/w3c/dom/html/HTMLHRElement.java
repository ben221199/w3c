package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLHRElement extends HTMLElement {
   public String             getAlign();
   public void               setAlign(String arg);

   public boolean            getNoShade();
   public void               setNoShade(boolean arg);

   public String             getSize();
   public void               setSize(String arg);

   public String             getWidth();
   public void               setWidth(String arg);

}

