package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLTableCellElement extends HTMLElement {
   public long               getCellIndex();
   public void               setCellIndex(long arg);

   public String             getAbbr();
   public void               setAbbr(String arg);

   public String             getAlign();
   public void               setAlign(String arg);

   public String             getAxis();
   public void               setAxis(String arg);

   public String             getBgColor();
   public void               setBgColor(String arg);

   public String             getCh();
   public void               setCh(String arg);

   public String             getChOff();
   public void               setChOff(String arg);

   public long               getColSpan();
   public void               setColSpan(long arg);

   public String             getHeaders();
   public void               setHeaders(String arg);

   public String             getHeight();
   public void               setHeight(String arg);

   public boolean            getNoWrap();
   public void               setNoWrap(boolean arg);

   public long               getRowSpan();
   public void               setRowSpan(long arg);

   public String             getScope();
   public void               setScope(String arg);

   public String             getVAlign();
   public void               setVAlign(String arg);

   public String             getWidth();
   public void               setWidth(String arg);

}

