package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLDivElement extends HTMLElement {
   public String             getAlign();
   public void               setAlign(String arg);

}

