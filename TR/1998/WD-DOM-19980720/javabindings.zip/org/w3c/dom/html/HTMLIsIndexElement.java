package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLIsIndexElement extends HTMLElement {
   public HTMLFormElement    getForm();

   public String             getPrompt();
   public void               setPrompt(String arg);

}

