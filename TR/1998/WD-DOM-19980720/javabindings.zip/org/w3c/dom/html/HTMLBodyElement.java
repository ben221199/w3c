package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLBodyElement extends HTMLElement {
   public String             getALink();
   public void               setALink(String arg);

   public String             getBackground();
   public void               setBackground(String arg);

   public String             getBgColor();
   public void               setBgColor(String arg);

   public String             getLink();
   public void               setLink(String arg);

   public String             getText();
   public void               setText(String arg);

   public String             getVLink();
   public void               setVLink(String arg);

}

