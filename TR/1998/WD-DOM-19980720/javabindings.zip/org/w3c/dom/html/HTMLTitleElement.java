package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLTitleElement extends HTMLElement {
   public String             getText();
   public void               setText(String arg);

}

