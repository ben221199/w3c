package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLMetaElement extends HTMLElement {
   public String             getContent();
   public void               setContent(String arg);

   public String             getHttpEquiv();
   public void               setHttpEquiv(String arg);

   public String             getName();
   public void               setName(String arg);

   public String             getScheme();
   public void               setScheme(String arg);

}

