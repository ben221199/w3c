package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLCollection {
   public long               getLength();

   public Node               item(long index);
   public Node               namedItem(String name);
}

