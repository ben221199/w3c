package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLLIElement extends HTMLElement {
   public String             getType();
   public void               setType(String arg);

   public long               getValue();
   public void               setValue(long arg);

}

