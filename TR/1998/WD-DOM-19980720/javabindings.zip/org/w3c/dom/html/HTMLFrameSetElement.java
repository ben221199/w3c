package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLFrameSetElement extends HTMLElement {
   public String             getCols();
   public void               setCols(String arg);

   public String             getRows();
   public void               setRows(String arg);

}

