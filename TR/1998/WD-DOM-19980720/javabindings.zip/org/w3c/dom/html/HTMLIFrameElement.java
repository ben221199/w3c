package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLIFrameElement extends HTMLElement {
   public String             getAlign();
   public void               setAlign(String arg);

   public String             getFrameBorder();
   public void               setFrameBorder(String arg);

   public String             getHeight();
   public void               setHeight(String arg);

   public String             getLongDesc();
   public void               setLongDesc(String arg);

   public String             getMarginHeight();
   public void               setMarginHeight(String arg);

   public String             getMarginWidth();
   public void               setMarginWidth(String arg);

   public String             getName();
   public void               setName(String arg);

   public String             getScrolling();
   public void               setScrolling(String arg);

   public String             getSrc();
   public void               setSrc(String arg);

   public String             getWidth();
   public void               setWidth(String arg);

}

