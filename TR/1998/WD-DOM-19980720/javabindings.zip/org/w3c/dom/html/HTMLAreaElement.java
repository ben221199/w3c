package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLAreaElement extends HTMLElement {
   public String             getAccessKey();
   public void               setAccessKey(String arg);

   public String             getAlt();
   public void               setAlt(String arg);

   public String             getCoords();
   public void               setCoords(String arg);

   public String             getHref();
   public void               setHref(String arg);

   public boolean            getNoHref();
   public void               setNoHref(boolean arg);

   public String             getShape();
   public void               setShape(String arg);

   public long               getTabIndex();
   public void               setTabIndex(long arg);

   public String             getTarget();
   public void               setTarget(String arg);

}

