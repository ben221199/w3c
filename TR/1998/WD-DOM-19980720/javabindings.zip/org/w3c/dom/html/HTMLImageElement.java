package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLImageElement extends HTMLElement {
   public String             getLowSrc();
   public void               setLowSrc(String arg);

   public String             getName();
   public void               setName(String arg);

   public String             getAlign();
   public void               setAlign(String arg);

   public String             getAlt();
   public void               setAlt(String arg);

   public String             getBorder();
   public void               setBorder(String arg);

   public String             getHeight();
   public void               setHeight(String arg);

   public String             getHspace();
   public void               setHspace(String arg);

   public boolean            getIsMap();
   public void               setIsMap(boolean arg);

   public String             getLongDesc();
   public void               setLongDesc(String arg);

   public String             getSrc();
   public void               setSrc(String arg);

   public String             getUseMap();
   public void               setUseMap(String arg);

   public String             getVspace();
   public void               setVspace(String arg);

   public String             getWidth();
   public void               setWidth(String arg);

}

