package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLTableRowElement extends HTMLElement {
   public long               getRowIndex();
   public void               setRowIndex(long arg);

   public long               getSectionRowIndex();
   public void               setSectionRowIndex(long arg);

   public HTMLCollection     getCells();
   public void               setCells(HTMLCollection arg);

   public String             getAlign();
   public void               setAlign(String arg);

   public String             getBgColor();
   public void               setBgColor(String arg);

   public String             getCh();
   public void               setCh(String arg);

   public String             getChOff();
   public void               setChOff(String arg);

   public String             getVAlign();
   public void               setVAlign(String arg);

   public HTMLElement        insertCell(long index);
   public void               deleteCell(long index);
}

