package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLObjectElement extends HTMLElement {
   public HTMLFormElement    getForm();

   public String             getCode();
   public void               setCode(String arg);

   public String             getAlign();
   public void               setAlign(String arg);

   public String             getArchive();
   public void               setArchive(String arg);

   public String             getBorder();
   public void               setBorder(String arg);

   public String             getCodeBase();
   public void               setCodeBase(String arg);

   public String             getCodeType();
   public void               setCodeType(String arg);

   public String             getData();
   public void               setData(String arg);

   public boolean            getDeclare();
   public void               setDeclare(boolean arg);

   public String             getHeight();
   public void               setHeight(String arg);

   public String             getHspace();
   public void               setHspace(String arg);

   public String             getName();
   public void               setName(String arg);

   public String             getStandby();
   public void               setStandby(String arg);

   public long               getTabIndex();
   public void               setTabIndex(long arg);

   public String             getType();
   public void               setType(String arg);

   public String             getUseMap();
   public void               setUseMap(String arg);

   public String             getVspace();
   public void               setVspace(String arg);

   public String             getWidth();
   public void               setWidth(String arg);

}

