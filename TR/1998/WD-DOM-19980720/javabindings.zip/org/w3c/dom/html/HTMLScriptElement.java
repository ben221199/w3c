package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLScriptElement extends HTMLElement {
   public String             getText();
   public void               setText(String arg);

   public String             getHtmlFor();
   public void               setHtmlFor(String arg);

   public String             getEvent();
   public void               setEvent(String arg);

   public String             getCharset();
   public void               setCharset(String arg);

   public boolean            getDefer();
   public void               setDefer(boolean arg);

   public String             getSrc();
   public void               setSrc(String arg);

   public String             getType();
   public void               setType(String arg);

}

