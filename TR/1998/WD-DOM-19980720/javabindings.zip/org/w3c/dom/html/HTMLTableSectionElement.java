package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLTableSectionElement extends HTMLElement {
   public String             getAlign();
   public void               setAlign(String arg);

   public String             getVAlign();
   public void               setVAlign(String arg);

   public HTMLCollection     getRows();
   public void               setRows(HTMLCollection arg);

   public HTMLElement        insertRow(long index);
   public void               deleteRow(long index);
}

