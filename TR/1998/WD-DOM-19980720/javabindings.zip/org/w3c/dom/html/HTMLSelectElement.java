package org.w3c.dom.html;

import org.w3c.dom.*;

public interface HTMLSelectElement extends HTMLElement {
   public String             getType();

   public long               getSelectedIndex();
   public void               setSelectedIndex(long arg);

   public String             getValue();
   public void               setValue(String arg);

   public long               getLength();
   public void               setLength(long arg);

   public HTMLFormElement    getForm();

   public HTMLCollection     getOptions();
   public void               setOptions(HTMLCollection arg);

   public boolean            getDisabled();
   public void               setDisabled(boolean arg);

   public boolean            getMultiple();
   public void               setMultiple(boolean arg);

   public String             getName();
   public void               setName(String arg);

   public long               getSize();
   public void               setSize(long arg);

   public long               getTabIndex();
   public void               setTabIndex(long arg);

   public void               add(HTMLElement element, 
                                 HTMLElement before);
   public void               remove(long index);
   public void               blur();
   public void               focus();
}

