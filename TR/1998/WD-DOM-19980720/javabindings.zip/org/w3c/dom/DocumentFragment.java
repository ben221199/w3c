package org.w3c.dom;

public interface DocumentFragment extends Node {
   public Document           getMasterDoc();

}

