package org.w3c.dom;

public interface Entity extends Node {
   public String             getPublicId();
   public void               setPublicId(String arg);

   public String             getSystemId();
   public void               setSystemId(String arg);

   public String             getNotationName();
   public void               setNotationName(String arg);

}

