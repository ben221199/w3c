package org.w3c.dom;

public interface Notation extends Node {
   public String             getPublicId();
   public void               setPublicId(String arg);

   public String             getSystemId();
   public void               setSystemId(String arg);

}

