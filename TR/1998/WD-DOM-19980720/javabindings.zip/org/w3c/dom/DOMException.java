package org.w3c.dom;

public class DOMException extends RuntimeException {
 public static final int UNSUPPORTED_DOCUMENT_ERR= 1;
 public static final int NOT_CHILD_ERR= 2;
 public static final int NO_CHILDREN_ALLOWED_ERR= 3;
 public static final int INDEX_SIZE_ERR= 4;
 public static final int WSTRING_SIZE_ERR= 5;
 public static final int DATA_SIZE_ERR= 6;


   public int   code;
}

