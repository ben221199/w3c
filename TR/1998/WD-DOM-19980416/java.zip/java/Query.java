package org.w3c.dom;

public interface Query {
   public QueryExpression   getExpression();
   public void              setExpression(QueryExpression arg);

 public String            getQuery();
 public void              setQuery(String query);
}

