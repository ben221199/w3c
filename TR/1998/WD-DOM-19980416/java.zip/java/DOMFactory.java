package org.w3c.dom;

public interface DOMFactory {
 public Document          createDocument();
 public DocumentContext   createDocumentContext();
 public Element           createElement(String tagName, 
                                        AttributeList attributes);
 public Text              createTextNode(String data);
 public Comment           createComment(String data);
 public PI                createPI(String name, 
                                   String data);
 public Attribute         createAttribute(String name, 
                                          NodeList value);
}

