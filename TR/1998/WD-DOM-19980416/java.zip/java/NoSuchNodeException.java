package org.w3c.dom;


public class NoSuchNodeException extends Exception {};
