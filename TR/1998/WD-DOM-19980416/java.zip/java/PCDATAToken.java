package org.w3c.dom;


public interface PCDATAToken extends Node {
}

