package org.w3c.dom;


public interface Comment extends Node {
   public String            getData();
   public void              setData(String arg);

}

