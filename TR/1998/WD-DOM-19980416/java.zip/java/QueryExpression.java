package org.w3c.dom;

public interface QueryExpression {
 public boolean           isTerm();
}

