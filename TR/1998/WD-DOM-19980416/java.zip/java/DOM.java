package org.w3c.dom;


public interface DOM {
   public Document          createDocument(String type);
   public boolean           hasFeature(String feature);
}

