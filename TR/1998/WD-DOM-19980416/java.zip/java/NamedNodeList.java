package org.w3c.dom;

public interface NamedNodeList extends NodeList {
 public Node              getItem(String nodeName);
 public Node              setItem(String nodeName, 
                                  Node node);
}

