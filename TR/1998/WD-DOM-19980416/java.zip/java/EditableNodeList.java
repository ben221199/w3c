package org.w3c.dom;

public interface EditableNodeList {
 public Node              replace(int index, 
                                  Node replaceNode);
 public Node              insert(int index, 
                                 Node newNode);
 public Node              remove(int index);
}

