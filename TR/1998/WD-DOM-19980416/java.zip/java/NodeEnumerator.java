package org.w3c.dom;

public interface NodeEnumerator {
 public Node              getFirst();
 public Node              getNext();
 public Node              getPrevious();
 public Node              getLast();
 public Node              getCurrent();
 public boolean           atStart();
 public boolean           atEnd();
}

