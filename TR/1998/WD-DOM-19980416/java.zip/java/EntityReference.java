package org.w3c.dom;


public interface EntityReference {
   public boolean           getIsExpanded();
   public void              setIsExpanded(boolean arg);

   public void              expand( );
}

