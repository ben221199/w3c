package org.w3c.dom;


public class NotMyChildException extends Exception {};
