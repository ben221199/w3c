package org.w3c.dom;


public interface Element extends Node {
   public String            getTagName();
   public NodeIterator      getAttributes();
   public String            getAttribute(name name);
   public void              setAttribute(String name, 
                                         String value);
   public void              removeAttribute(String name);
   public Attribute         getAttributeNode(name name);
   public void              setAttributeNode(Attribute newAttr);
   public void              removeAttributeNode(Attribute oldAttr);
   public void              getElementsByTagName(String tagname);
   public void              normalize();
}

