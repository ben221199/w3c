package org.w3c.dom;


public interface AttributeList {
   public Attribute         getAttribute(String attrName);
   public Attribute         setAttribute(Attribute attr);
   public Attribute         remove(String attrName)  public class NoSuchAttributeException extends Exception {};
;
   public Attribute         item(int index)  public class NoSuchAttributeException extends Exception {};
;
   public int               getLength();
}

