package org.w3c.dom;


public class NoSuchAttributeException extends Exception {};
