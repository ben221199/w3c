package org.w3c.dom;

public interface QueryTerm extends QueryExpression {
   public static final int ELEMENT      = 1;
   public static final int ATTRIBUTE    = 2;
   public static final int TEXT         = 3;
   public static final int NUMBER       = 4;


   public String            getText();
   public void              setText(String arg);

}

