package org.w3c.dom;

public interface QueryOperator extends QueryExpression {
   public static final int AND          = 1;
   public static final int OR           = 2;
   public static final int NOT          = 3;
   public static final int VALUE        = 4;
   public static final int CHILD        = 5;


   public QueryExpressionListgetLeft();
   public void              setLeft(QueryExpressionList arg);

   public QueryExpressionListgetRight();
   public void              setRight(QueryExpressionList arg);

}

