package org.w3c.dom;


public interface DocumentContext {
   public Document          getDocument();
   public void              setDocument(Document arg);

}

